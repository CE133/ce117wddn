using System;

namespace cal
{
	public class SUB
	{
		public int subtraction(int a,int b)
		{
			return a-b;
		}
	}
}