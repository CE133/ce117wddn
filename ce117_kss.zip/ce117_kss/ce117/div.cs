using System;

namespace cal
{
	public class DIV
	{
		public int division(int a,int b)
		{
			return a/b;
		}
	}
}