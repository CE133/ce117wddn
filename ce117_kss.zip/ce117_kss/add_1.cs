using System.Reflection;
using System;
[assembly:AssemblyVersion("1.0.0.0")]

namespace cal
{
	public class Calc
	{
		public int addition(int a,int b)
        {
            Console.WriteLine("New");
            return a+b;
		}
        public int multiply(int a, int b)
        {
            Console.WriteLine("New");
            return a * b;        }
        public int division(int a, int b)
        {
            Console.WriteLine("New");
            return a / b;
        }
        public int subtraction(int a, int b)
        {
            Console.WriteLine("New");
            return a - b;
        }


    }
}
