using System;

namespace Dem
{
    public class Demo
    {
        public void msg() { 
        Console.WriteLine("Hello World");
            return;
        }
    }
}
