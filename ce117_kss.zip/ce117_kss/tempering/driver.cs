using System;
using Dem;
namespace Dri
{
	public class Drive
	{
        public static void Main()
        {
            Demo d = new Demo();
            d.msg();
        }
    }
}
