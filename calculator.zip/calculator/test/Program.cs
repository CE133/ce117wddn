﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using calculator;
namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc c = new Calc();
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Addition:" + (c.addition(a, b)));
            Console.WriteLine("Subtraction:" + (c.subtraction(a, b)));
            Console.WriteLine("Multiplication:" + (c.multiplication(a, b)));
            Console.WriteLine("Division:" + (c.division(a, b)));
            Console.ReadKey();
        }
    }
}
