﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace aspKSS
{
    public partial class ksslab4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = Application["count"] + "Number of Users Online";
        }

        protected void abc(object sender, CommandEventArgs e)
        {
            int i = Convert.ToInt32(TextBox1.Text);
            int j = Convert.ToInt32(TextBox2.Text);
            if (e.CommandName=="add")
            {
                Label1.Text = (i + j) + "";
            }
            else
            {
                Label1.Text = (i * j) + "";
            }
            Label2.Text = Application["count"] + " is Number of Users Online";
        }

  
    }
}