﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Calc
    {
        public int addition(int a, int b)
        {
            return a + b;
        }
        public int subtraction(int a, int b)
        {
            return a - b;
        }
        public int multiply(int a, int b)
        {
            return a * b;
        }
        public int division(int a, int b)
        {
            return a / b;
        }
    }
}
