﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
namespace Prog
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc c = new Calc();
            Console.WriteLine(c.addition(3, 4));
            Console.WriteLine(c.subtraction(3, 4));
            Console.WriteLine(c.multiply(3, 4));
            Console.WriteLine(c.division(3, 4));
        }
    }
}
