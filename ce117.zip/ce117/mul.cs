using System;

namespace cal
{
	public class MUL
	{
		public int multiply(int a,int b)
		{
			return a*b;
		}
	}
}