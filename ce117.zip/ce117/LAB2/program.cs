using System;
using cal;
namespace pro
{
	public class Prog
	{
		public static void Main()
		{
			Calc c=new Calc();
			Console.WriteLine(c.addition(3,4));
			Console.WriteLine(c.subtraction(3,4));
			Console.WriteLine(c.multiply(3,4));
			Console.WriteLine(c.division(3,4));
		}
		
	}
}
