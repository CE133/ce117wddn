using System.Reflection;
[assembly:AssemblyVersion("1.0.0.0")]

namespace cal
{
	public class Calc
	{
		public int addition(int a,int b)
		{
			return a+b;
            Console.WriteLine("New");
		}
        public int multiply(int a, int b)
        {
            return a * b;
            Console.WriteLine("New");
        }
        public int division(int a, int b)
        {
            return a / b;
            Console.WriteLine("New");
        }
        public int subtraction(int a, int b)
        {
            return a - b;
            Console.WriteLine("New");
        }


    }
}
