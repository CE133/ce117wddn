using System;

namespace cal
{
	public class Calc
	{
		public int addition(int a,int b)
		{
			return a+b;
		}
        public int multiply(int a, int b)
        {
            return a * b;
        }
        public int division(int a, int b)
        {
            return a / b;
        }
        public int subtraction(int a, int b)
        {
            return a - b;
        }


    }
}
