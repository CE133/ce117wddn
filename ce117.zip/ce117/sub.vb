Imports System

Namespace cal
    Public Class [SUB]
        Public Function subtraction(ByVal a As Integer, ByVal b As Integer) As Integer
            Return a - b
        End Function
    End Class
End Namespace
